/* generated configuration header file - do not edit */
#ifndef RM_HS300X_CFG_H_
#define RM_HS300X_CFG_H_
#ifdef __cplusplus
            extern "C" {
            #endif

#define RM_HS300X_CFG_PARAM_CHECKING_ENABLE   (BSP_CFG_PARAM_CHECKING_ENABLE)
#define RM_HS300X_CFG_DATA_BOTH_HUMIDITY_TEMPERATURE (1)
#define RM_HS300X_CFG_PROGRAMMING_MODE (0)

#ifdef __cplusplus
            }
            #endif
#endif /* RM_HS300X_CFG_H_ */
