/* generated configuration header file - do not edit */
#ifndef R_CGC_CFG_H_
#define R_CGC_CFG_H_
#ifdef __cplusplus
extern "C" {
#endif

#define CGC_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#define CGC_CFG_USE_LOW_VOLTAGE_MODE RA_NOT_DEFINED

#ifdef __cplusplus
}
#endif
#endif /* R_CGC_CFG_H_ */
