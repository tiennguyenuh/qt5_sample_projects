/* generated common source file - do not edit */
#include "common_data.h"
iic_master_instance_ctrl_t g_i2c_master0_ctrl;
const iic_master_extended_cfg_t g_i2c_master0_extend =
		{ .timeout_mode = IIC_MASTER_TIMEOUT_MODE_SHORT, .timeout_scl_low =
				IIC_MASTER_TIMEOUT_SCL_LOW_ENABLED, .smbus_operation = 0,
				/* Actual calculated bitrate: 98425. Actual calculated duty cycle: 50%. */.clock_settings.brl_value =
						28, .clock_settings.brh_value = 28,
				.clock_settings.cks_value = 3, .clock_settings.sddl_value = 0,
				.clock_settings.dlcs_value = 0, };
const i2c_master_cfg_t g_i2c_master0_cfg = { .channel = 0, .rate =
		I2C_MASTER_RATE_STANDARD, .slave = 0x00, .addr_mode =
		I2C_MASTER_ADDR_MODE_7BIT,
#define RA_NOT_DEFINED (1)
#if (RA_NOT_DEFINED == RA_NOT_DEFINED)
		.p_transfer_tx = NULL,
#else
                .p_transfer_tx       = &RA_NOT_DEFINED,
#endif
#if (RA_NOT_DEFINED == RA_NOT_DEFINED)
		.p_transfer_rx = NULL,
#else
                .p_transfer_rx       = &RA_NOT_DEFINED,
#endif
#undef RA_NOT_DEFINED
		.p_callback = rm_comms_i2c_callback, .p_context = NULL,
#if defined(VECTOR_NUMBER_IIC0_RXI)
    .rxi_irq             = VECTOR_NUMBER_IIC0_RXI,
#else
		.rxi_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_IIC0_TXI)
    .txi_irq             = VECTOR_NUMBER_IIC0_TXI,
#else
		.txi_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_IIC0_TEI)
    .tei_irq             = VECTOR_NUMBER_IIC0_TEI,
#else
		.tei_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_IIC0_ERI)
    .eri_irq             = VECTOR_NUMBER_IIC0_ERI,
#else
		.eri_irq = FSP_INVALID_VECTOR,
#endif
		.ipl = (5), .p_extend = &g_i2c_master0_extend, };
/* Instance structure to use this module. */
const i2c_master_instance_t g_i2c_master0 = { .p_ctrl = &g_i2c_master0_ctrl,
		.p_cfg = &g_i2c_master0_cfg, .p_api = &g_i2c_master_on_iic };
#if BSP_CFG_RTOS
#if BSP_CFG_RTOS == 1
#if !defined(g_comms_i2c_bus0_recursive_mutex)
TX_MUTEX g_comms_i2c_bus0_recursive_mutex_handle;
CHAR g_comms_i2c_bus0_recursive_mutex_name[] = "g_comms_i2c_bus0 recursive mutex";
#endif
#if !defined(g_comms_i2c_bus0_blocking_semaphore)
TX_SEMAPHORE g_comms_i2c_bus0_blocking_semaphore_handle;
CHAR g_comms_i2c_bus0_blocking_semaphore_name[] = "g_comms_i2c_bus0 blocking semaphore";
#endif
#elif BSP_CFG_RTOS == 2
#if !defined(g_comms_i2c_bus0_recursive_mutex)
SemaphoreHandle_t g_comms_i2c_bus0_recursive_mutex_handle;
StaticSemaphore_t g_comms_i2c_bus0_recursive_mutex_memory;
#endif
#if !defined(g_comms_i2c_bus0_blocking_semaphore)
SemaphoreHandle_t g_comms_i2c_bus0_blocking_semaphore_handle;
StaticSemaphore_t g_comms_i2c_bus0_blocking_semaphore_memory;
#endif
#endif

#if !defined(g_comms_i2c_bus0_recursive_mutex)
/* Recursive Mutex for I2C bus */
rm_comms_i2c_mutex_t g_comms_i2c_bus0_recursive_mutex =
{
    .p_mutex_handle = &g_comms_i2c_bus0_recursive_mutex_handle,
#if BSP_CFG_RTOS == 1 // ThradX
    .p_mutex_name = &g_comms_i2c_bus0_recursive_mutex_name[0],
#elif BSP_CFG_RTOS == 2 // FreeRTOS
    .p_mutex_memory = &g_comms_i2c_bus0_recursive_mutex_memory,
#endif
};
#endif

#if !defined(g_comms_i2c_bus0_blocking_semaphore)
/* Semaphore for blocking */
rm_comms_i2c_semaphore_t g_comms_i2c_bus0_blocking_semaphore =
{
    .p_semaphore_handle = &g_comms_i2c_bus0_blocking_semaphore_handle,
#if BSP_CFG_RTOS == 1 // ThreadX
    .p_semaphore_name = &g_comms_i2c_bus0_blocking_semaphore_name[0],
#elif BSP_CFG_RTOS == 2 // FreeRTOS
    .p_semaphore_memory = &g_comms_i2c_bus0_blocking_semaphore_memory,
#endif
};
#endif
#endif

/* Shared I2C Bus */
#define RA_NOT_DEFINED (1)
rm_comms_i2c_bus_extended_cfg_t g_comms_i2c_bus0_extended_cfg = {
#if !defined(g_i2c_master0)
		.p_driver_instance = (void*) &g_i2c_master0,
#elif !defined(RA_NOT_DEFINED)
    .p_driver_instance      = (void*)&RA_NOT_DEFINED,
#elif !defined(RA_NOT_DEFINED)
    .p_driver_instance      = (void*)&RA_NOT_DEFINED,
#endif
		.p_current_ctrl = NULL, .bus_timeout = 0xFFFFFFFF,
#if BSP_CFG_RTOS
#if !defined(g_comms_i2c_bus0_blocking_semaphore)
    .p_blocking_semaphore = &g_comms_i2c_bus0_blocking_semaphore,
#if !defined(g_comms_i2c_bus0_recursive_mutex)
    .p_bus_recursive_mutex = &g_comms_i2c_bus0_recursive_mutex,
#else
    .p_bus_recursive_mutex = NULL,
#endif
#else
    .p_bus_recursive_mutex = NULL,
    .p_blocking_semaphore = NULL,
#endif
#else
#endif

#if (0)
    .p_elc = (void*)&g_elc,
    .p_timer = (void*)&g_timer,
#else
		.p_elc = NULL, .p_timer = NULL,
#endif
		};
icu_instance_ctrl_t g_sensorIRQ_ctrl;
const external_irq_cfg_t g_sensorIRQ_cfg = { .channel = 14, .trigger =
		EXTERNAL_IRQ_TRIG_FALLING, .filter_enable = false, .clock_source_div =
		EXTERNAL_IRQ_CLOCK_SOURCE_DIV_64, .p_callback = sensorOBIRQCallback,
/** If NULL then do not add & */
#if defined(NULL)
    .p_context           = NULL,
#else
		.p_context = &NULL,
#endif
		.p_extend = NULL, .ipl = (2),
#if defined(VECTOR_NUMBER_ICU_IRQ14)
    .irq                 = VECTOR_NUMBER_ICU_IRQ14,
#else
		.irq = FSP_INVALID_VECTOR,
#endif
		};
/* Instance structure to use this module. */
const external_irq_instance_t g_sensorIRQ = { .p_ctrl = &g_sensorIRQ_ctrl,
		.p_cfg = &g_sensorIRQ_cfg, .p_api = &g_external_irq_on_icu };
#if BSP_FEATURE_CGC_HAS_OSTDCSE
const cgc_extended_cfg_t g_cgc0_cfg_extend =
{
    .ostd_enable = (1),
    .mostd_enable = (0),
    .sostd_enable = (0),
#if defined(VECTOR_NUMBER_CGC_MOSTD_STOP)
    .mostd_irq            = VECTOR_NUMBER_CGC_MOSTD_STOP,
#else
    .mostd_irq            = FSP_INVALID_VECTOR,
#endif
    .mostd_ipl            = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_CGC_SOSC_STOP)
    .sostd_irq            = VECTOR_NUMBER_CGC_SOSC_STOP,
#else
    .sostd_irq            = FSP_INVALID_VECTOR,
#endif
    .sostd_ipl            = (BSP_IRQ_DISABLED),
    .sdadc_b_clock_switch_enable = (0),
    .mostd_detection_time = 0,
    .sostd_detection_time = 0,
};
#endif

#if BSP_TZ_NONSECURE_BUILD
 #if defined(BSP_CFG_CLOCKS_SECURE) && BSP_CFG_CLOCKS_SECURE
  #error "The CGC registers are only accessible in the TrustZone Secure Project."
 #endif
#endif

const cgc_cfg_t g_cgc0_cfg = { .p_callback = NULL,
#if BSP_FEATURE_CGC_HAS_OSTDCSE
    .p_extend   = &g_cgc0_cfg_extend,
#else
		.p_extend = NULL,
#endif
		};

cgc_instance_ctrl_t g_cgc0_ctrl;
const cgc_instance_t g_cgc0 = { .p_api = &g_cgc_on_cgc, .p_ctrl = &g_cgc0_ctrl,
		.p_cfg = &g_cgc0_cfg, };
ioport_instance_ctrl_t g_ioport_ctrl;
const ioport_instance_t g_ioport = { .p_api = &g_ioport_on_ioport, .p_ctrl =
		&g_ioport_ctrl, .p_cfg = &g_bsp_pin_cfg, };
QueueHandle_t g_topic_queue;
#if 1
StaticQueue_t g_topic_queue_memory;
uint8_t g_topic_queue_queue_memory[64 * 16];
#endif
void rtos_startup_err_callback(void *p_instance, void *p_data);
SemaphoreHandle_t g_sens_data_mutex;
#if 1
StaticSemaphore_t g_sens_data_mutex_memory;
#endif
void rtos_startup_err_callback(void *p_instance, void *p_data);
SemaphoreHandle_t g_console_binary_semaphore;
#if 1
StaticSemaphore_t g_console_binary_semaphore_memory;
#endif
void rtos_startup_err_callback(void *p_instance, void *p_data);
SemaphoreHandle_t g_console_out_mutex;
#if 1
StaticSemaphore_t g_console_out_mutex_memory;
#endif
void rtos_startup_err_callback(void *p_instance, void *p_data);
SemaphoreHandle_t g_update_console_event;
#if 1
StaticSemaphore_t g_update_console_event_memory;
#endif
void rtos_startup_err_callback(void *p_instance, void *p_data);
SemaphoreHandle_t g_ob1203_semaphore;
#if 1
StaticSemaphore_t g_ob1203_semaphore_memory;
#endif
void rtos_startup_err_callback(void *p_instance, void *p_data);
void g_common_init(void) {
	g_topic_queue =
#if 1
			xQueueCreateStatic(
#else
                xQueueCreate(
                #endif
					16, 64
#if 1
					, &g_topic_queue_queue_memory[0], &g_topic_queue_memory
#endif
					);
	if (NULL == g_topic_queue) {
		rtos_startup_err_callback(g_topic_queue, 0);
	}
	g_sens_data_mutex =
#if 0
                #if 1
                xSemaphoreCreateRecursiveMutexStatic(&g_sens_data_mutex_memory);
                #else
                xSemaphoreCreateRecursiveMutex();
                #endif
                #else
#if 1
			xSemaphoreCreateMutexStatic(&g_sens_data_mutex_memory);
#else
                xSemaphoreCreateMutex();
                #endif
#endif
	if (NULL == g_sens_data_mutex) {
		rtos_startup_err_callback(g_sens_data_mutex, 0);
	}
	g_console_binary_semaphore =
#if 1
			xSemaphoreCreateBinaryStatic(&g_console_binary_semaphore_memory);
#else
                xSemaphoreCreateBinary();
                #endif
	if (NULL == g_console_binary_semaphore) {
		rtos_startup_err_callback(g_console_binary_semaphore, 0);
	}
	g_console_out_mutex =
#if 0
                #if 1
                xSemaphoreCreateRecursiveMutexStatic(&g_console_out_mutex_memory);
                #else
                xSemaphoreCreateRecursiveMutex();
                #endif
                #else
#if 1
			xSemaphoreCreateMutexStatic(&g_console_out_mutex_memory);
#else
                xSemaphoreCreateMutex();
                #endif
#endif
	if (NULL == g_console_out_mutex) {
		rtos_startup_err_callback(g_console_out_mutex, 0);
	}
	g_update_console_event =
#if 0
                #if 1
                xSemaphoreCreateRecursiveMutexStatic(&g_update_console_event_memory);
                #else
                xSemaphoreCreateRecursiveMutex();
                #endif
                #else
#if 1
			xSemaphoreCreateMutexStatic(&g_update_console_event_memory);
#else
                xSemaphoreCreateMutex();
                #endif
#endif
	if (NULL == g_update_console_event) {
		rtos_startup_err_callback(g_update_console_event, 0);
	}
	g_ob1203_semaphore =
#if 1
			xSemaphoreCreateBinaryStatic(&g_ob1203_semaphore_memory);
#else
                xSemaphoreCreateBinary();
                #endif
	if (NULL == g_ob1203_semaphore) {
		rtos_startup_err_callback(g_ob1203_semaphore, 0);
	}
}
