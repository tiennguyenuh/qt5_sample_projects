/*
 * usr_data.c
 *
 *  Created on: Jul 7, 2023
 *      Author: a5144482
 */

#include "common_utils.h"
#include "usr_data.h"

uint8_t total_data_in_queue[NUM_OF_CURRENT_SENSORS] = { RESET_VALUE };
