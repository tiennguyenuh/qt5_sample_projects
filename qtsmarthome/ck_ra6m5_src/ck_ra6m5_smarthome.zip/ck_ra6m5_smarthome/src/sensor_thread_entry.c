/***********************************************************************************************************************
 * File Name    : sensor_thread_entry.c
 * Description  : Contains data structures and functions
 ***********************************************************************************************************************/
/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2023 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/
#include "sensor_thread.h"
#include "RA_HS3001.h"
#include "common_utils.h"
#include "user_choice.h"
#include "usr_data.h"


#define UNUSED(x)  (void)(x)
#define INT_CHANNEL (1)

void RA_Init(void);
void updateData(void);

extern volatile sensor_demo_data_t g_demo_data;

/* For testing purpose later needs to be moved to the right location */
extern usr_hs3001_data_t app_hs3001_data;


extern TaskHandle_t sensor_thread;

void updateData(void)
{

    mqtt_rx_payload_t payload_data = {'\0'};
    static  uint8_t  msgId = ID_HS_DATA_PUSH;
    BaseType_t xHigherPriorityTaskWokenByPost = pdFALSE;

    app_hs3001_data.gs_humidity = g_demo_data.gs_demo_humidity;
    app_hs3001_data.gs_temperature = (g_demo_data.gs_demo_temperature * (float) 1.8) + (float) 32.0;


    if (ID_HS_DATA_PUSH == msgId)
    {
        payload_data.id = ID_HS_DATA_PUSH;
        xQueueGenericSendFromISR (g_topic_queue, &payload_data, &xHigherPriorityTaskWokenByPost, queueSEND_TO_FRONT);
        msgId = ID_HS_DATA_PUSH;
    }

}

/*******************************************************************************************************************//**
 * @brief       Quick setup for g_comms_i2c_bus0
 * @param[in]   p_args
 * @retval
 * @retval
 ***********************************************************************************************************************/
void g_comms_i2c_bus0_quick_setup(void)
{
    fsp_err_t err;
    i2c_master_instance_t *p_driver_instance = (i2c_master_instance_t*) g_comms_i2c_bus0_extended_cfg.p_driver_instance;
    /* Open I2C driver, this must be done before calling any COMMS API */
    err = p_driver_instance->p_api->open (p_driver_instance->p_ctrl, p_driver_instance->p_cfg);
    if (FSP_SUCCESS != err)
    {
        APP_ERR_TRAP(err);
    }
    else
    {
    }

    /* Create a semaphore for blocking if a semaphore is not NULL */
    if (NULL != g_comms_i2c_bus0_extended_cfg.p_blocking_semaphore)
    {
        *(g_comms_i2c_bus0_extended_cfg.p_blocking_semaphore->p_semaphore_handle) = xSemaphoreCreateCountingStatic (
                (UBaseType_t) 1, (UBaseType_t) 0,
                g_comms_i2c_bus0_extended_cfg.p_blocking_semaphore->p_semaphore_memory);
    }

    /* Create a recursive mutex for bus lock if a recursive mutex is not NULL */
    if (NULL != g_comms_i2c_bus0_extended_cfg.p_bus_recursive_mutex)
    {
        *(g_comms_i2c_bus0_extended_cfg.p_bus_recursive_mutex->p_mutex_handle) = xSemaphoreCreateRecursiveMutexStatic (
                g_comms_i2c_bus0_extended_cfg.p_bus_recursive_mutex->p_mutex_memory);
    }
}

/*******************************************************************************************************************//**
 * @brief       Initialization of UART and external interrupt
 * @param[in]
 * @retval
 * @retval
 ***********************************************************************************************************************/
void RA_Init(void)
{
    fsp_err_t err = FSP_SUCCESS;
    fsp_pack_version_t version =
    { RESET_VALUE };
    /* Version get API for FLEX pack information */
    R_FSP_VersionGet (&version);

    /* opening ExternalIRQ for IRQ14 P403 for OB1203 */
    err = R_ICU_ExternalIrqOpen (&g_sensorIRQ_ctrl, &g_sensorIRQ_cfg);
    if (FSP_SUCCESS != err)
    {
        APP_ERR_TRAP(err);
    }
    else
    {
    }
}

/* Sensor_Thread entry function */
/* pvParameters contains TaskHandle_t */
void sensor_thread_entry(void *pvParameters)
{
    FSP_PARAMETER_NOT_USED(pvParameters);

    RA_Init ();
    g_comms_i2c_bus0_quick_setup ();

#if  _HS3001_SENSOR_ENABLE_
    /* Open HS3001 */
    g_hs300x_sensor0_quick_setup ();
#endif

    xTaskNotifyWait(pdFALSE, pdFALSE, (uint32_t* )&sensor_thread, portMAX_DELAY);

    /* start user timer */
    user_timer_start ();
    while (1)
    {

#if _HS3001_SENSOR_ENABLE_
        /* Read HS3001 sensor data */
        hs3001_get ();
        vTaskDelay (5);
#endif
    }
}

void sensorOBIRQCallback(external_irq_callback_args_t *p_args)
{
    UNUSED(p_args);
}
