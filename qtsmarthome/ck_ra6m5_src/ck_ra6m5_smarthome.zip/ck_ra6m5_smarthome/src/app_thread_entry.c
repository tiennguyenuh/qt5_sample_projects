/***********************************************************************************************************************
 * File Name    : app_thread_entry.c
 * Description  : Contains data structures and functions used in Cloud Connectivity application
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * Copyright [2015-2023] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
 *
 * The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
 * and/or its licensors ("Renesas") and subject to statutory and contractual protections.
 *
 * This file is subject to a Renesas FSP license agreement. Unless otherwise agreed in an FSP license agreement with
 * Renesas: 1) you may not use, copy, modify, distribute, display, or perform the contents; 2) you may not use any name
 * or mark of Renesas for advertising or publicity purposes or in connection with your use of the contents; 3) RENESAS
 * MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED
 * "AS IS" WITHOUT ANY EXPRESS OR IMPLIED WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR
 * CONSEQUENTIAL DAMAGES, INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF
 * CONTRACT OR TORT, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents
 * included in this file may be subject to different terms.
 **********************************************************************************************************************/
#include "app_thread.h"
#include "common_utils.h"
#include "usr_hal.h"
#include "usr_config.h"
#include "usr_data.h"
#include "sensor_thread.h"
#include "i2c_sensor.h"

/*************************************************************************************
 * Macro definitions
 ************************************************************************************/
#define MILLISECONDS_PER_SECOND             (1000U)
#define MILLISECONDS_PER_TICK               ( MILLISECONDS_PER_SECOND / configTICK_RATE_HZ )
#define APP_DEBUG_MSG_SEQ_CNTRL             (1)
#define APP_DEBUG_MSG_CNTRL                 (1)
#define DATA_LENGTH 80u

extern TaskHandle_t sensor_thread;

/*************************************************************************************
 * Private functions
 ************************************************************************************/

char cBuffer[16] = { RESET_VALUE };
char   temp_str[21][32] =  { RESET_VALUE };

/* For testing purpose the initial values are random, later needs to be moved to the right location */
usr_hs3001_data_t app_hs3001_data = {RESET_VALUE};

static mqtt_rx_payload_t mq_data = { RESET_VALUE };

/*******************************************************************************************************************//**
 * @brief      Application Thread entry function
 * @param[in]   pvParameters     contains TaskHandle_t
 * @retval
 * @retval
 ***********************************************************************************************************************/
static volatile uint8_t g_uart_sensor_event = { 0x00 };

fsp_err_t uart_sensor_write(uint8_t *p_msg);
static fsp_err_t uart_sensor_initialize(void);
void send_temp_and_humid();
void send_acl();

/* Global variable */
uint8_t xyz_axis[6]      = {RESET_VALUE};
char flt_str[64]        = {RESET_VALUE};
float x_axis            = 0.0f;
float y_axis            = 0.0f;
float z_axis            = 0.0f;

fsp_err_t uart_sensor_write(uint8_t *p_msg)
{
    fsp_err_t err = FSP_SUCCESS;
    uint8_t msg_len = RESET_VALUE;
    uint32_t local_timeout = (DATA_LENGTH * UINT16_MAX);
    char *p_temp_ptr = (char *)p_msg;

    /* Calculate length of message received including null terminator */
    msg_len = (uint8_t)strlen(p_temp_ptr) + 1;

    /* Reset callback capture variable */
    g_uart_sensor_event = RESET_VALUE;

    /* Writing to terminal */
    err = R_SCI_UART_Write(&g_sensor_uart_ctrl, p_msg, msg_len);
    if (FSP_SUCCESS != err)
    {
        // Handle write error
        return err;
    }

    /* Check for event transfer complete */
    while ((UART_EVENT_TX_COMPLETE != g_uart_sensor_event) && (--local_timeout))
    {
        /* Check if any error event occurred */
        if (UART_ERROR_EVENTS == g_uart_sensor_event)
        {
            // Handle UART error event
            return FSP_ERR_TRANSFER_ABORTED;
        }
    }
    if (RESET_VALUE == local_timeout)
    {
        // Handle timeout error
        err = FSP_ERR_TIMEOUT;
    }
    return err;
}


static fsp_err_t uart_sensor_initialize(void)
{
    fsp_err_t err = FSP_SUCCESS;

    /* Initialize UART channel with baud rate 115200 */
    err = R_SCI_UART_Open(&g_sensor_uart_ctrl, &g_sensor_uart_cfg);
    if (FSP_SUCCESS != err)
    {
        //APP_ERR_PRINT ("\r\n**  R_SCI_UART_Open API failed  **\r\n");
    }
    return err;
}

void send_temp_and_humid() {

    char buffer[80];

    // Format the temperature and humidity into a string
    snprintf(buffer, sizeof(buffer), "\r\nT:%.2f,%.2f\r\n", app_hs3001_data.gs_temperature, app_hs3001_data.gs_humidity);

    uart_sensor_write((uint8_t *)buffer);
}

void send_acl() {

    char buffer[80];

    // Format the acl data into a string
	x_axis = (float) (xyz_axis[0] | (xyz_axis[1] << BIT_SHIFT_8));   // X-axis value
	y_axis = (float) (xyz_axis[2] | (xyz_axis[3] << BIT_SHIFT_8));   // Y-axis value
	z_axis = (float) (xyz_axis[4] | (xyz_axis[5] << BIT_SHIFT_8));   // Z-axis value

	snprintf(buffer,sizeof(buffer),"\r\nA:%.02f,%.02f,%.02f\r\n",x_axis,y_axis,z_axis);

    uart_sensor_write((uint8_t *)buffer);
}

void app_thread_entry(void *pvParameters)
{	fsp_err_t               err = FSP_SUCCESS;
	BaseType_t              bt_status = pdFALSE;

	FSP_PARAMETER_NOT_USED (pvParameters);

    xTaskNotifyFromISR(sensor_thread, 1, 1, NULL);

    err = uart_sensor_initialize();
    if (err != FSP_SUCCESS)
    {
    }

    err = init_sensor();

    while (1)
    {
		R_BSP_SoftwareDelay(SENSOR_READ_DELAY, BSP_DELAY_UNITS_SECONDS);

        bt_status = xQueueReceive (g_topic_queue, &mq_data, QUEUE_WAIT);

        if( pdTRUE == bt_status )
        {
            if(APP_DEBUG_MSG_SEQ_CNTRL)
            {
            }
			
            switch (mq_data.id)
            {
                case ID_HS_DATA_PULL:
                case ID_HS_DATA_PUSH:
                {
                     send_temp_and_humid();
                 }
                 break;

                default:
                {
                }
                break;
            }

        }

        /* Read PMOD ACL sensor data */
		err =  read_sensor_data(xyz_axis);

		if(FSP_SUCCESS != err)
		{
			deinit_sensor();
		}
		else
		{
			 /*
			  * X,Y,Z - axis data has to be evaluated so accessing particular array value,
			  * shifting it by 8 bits obtains data value to float variable
			  */
			send_acl();

			/* 3 Seconds Wait time between successive readings */
//			R_BSP_SoftwareDelay(SENSOR_READ_DELAY, BSP_DELAY_UNITS_SECONDS);
		}

    }
}

void sensor_uart_callback(uart_callback_args_t *p_args)
{
    /* Handle the UART event */
    switch (p_args->event)
    {
        /* Transmit complete */
        case UART_EVENT_TX_COMPLETE:
        {
            g_uart_sensor_event = p_args->event;
            break;
        }
        default:
        {
        }
    }
}
